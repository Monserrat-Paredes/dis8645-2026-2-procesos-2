// hay 3 elementos
// lucecita
// perilla
// pulsador

// lucecita necesita R de 220
// perilla necesita nada
// pulsador necesita R de 10k

// entradas
// o sensores
// perilla - posicion rotacional / giro
// pulsador - si o no hay presion

// salidas
// o actuadores
// lucecita

// ya pero y?

// pulsador: prender y apagar todo
// potenciometro: frecuencia de parpadeo

// lucecita: prender y apagarse
// segun lo que diga boton y perilla

// por lo tanto
// boton tiene dos estados
// prendido y apagado

// perilla va a tener
// una posicion que va a ser
// usada por el sistema
// para impactar en parpadeo lucecita



#include <stdio.h>
#include "pico/stdlib.h"

#include "Boton.h"
#include "Perilla.h"
#include "Lucecita.h"

int main() {
  stdio_init_all();


  // instanciar Boton llamado pulsador
  // a partir de la clase Boton
  // con el parametro
  Boton pulsador(7);

  // lo mismo pero con perilla
  Perilla parpadeo(26);

  Lucecita luz(6);
  Lucecita luzSegunda(5);
  bool sistemaPrendido = false;
  bool botonEstadoAnterior = false;

  

while (true) {

  // leer boton y posicion de perilla
  pulsador.leer();
  parpadeo.leer();

  // si la perilla esta dentro del rango
  if (parpadeo.posicion >= 2000 && parpadeo.posicion <= 3000) {

    // parpadeo constante 
    luzSegunda.parpadear(250, 250);

  } else {

    // fuera del rango, apagar segunda luz
    luzSegunda.apagar();

  }


  // detectar nueva pulsacion
  if (pulsador.presionado == true && botonEstadoAnterior == false) {
    sistemaPrendido = !sistemaPrendido;
  }

  // guardar estado del boton
  botonEstadoAnterior = pulsador.presionado;

  // controlar la luz
  if (sistemaPrendido == true) {

    luz.parpadear(500, 500);

  } else {

    luz.apagar();

  }

  sleep_ms(10);
}



    if (parpadeo.posicion < 4096 /2) {

      luz.apagar();
    } else {
      luz.prender();
    }

   
    printf("%d\n", parpadeo.posicion);
    sleep_ms(250);
  }
